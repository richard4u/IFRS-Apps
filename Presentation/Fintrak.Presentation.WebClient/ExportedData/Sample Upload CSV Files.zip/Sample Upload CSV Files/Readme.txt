|--------Fintrak Software

The headers of each CSV should be used in your Document

If you would use the Sample files, Please know that the headers of each Sample CSV Templates should not be changed
as the Application needs this to run the Upload.